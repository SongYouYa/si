function showError(title, description) {
    $('#title').html(title);
    $('#description').html(description);
}

(function() {

  var module = angular.module('manuskript.load.controller', []);

  module.controller('ManuskriptLoadController', function($scope) {
  });
})();
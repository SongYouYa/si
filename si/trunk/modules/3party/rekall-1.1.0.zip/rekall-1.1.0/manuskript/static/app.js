(function() {

  var module = angular.module('manuskript.app', [
    'manuskript.app.controller',
  ]);

})();
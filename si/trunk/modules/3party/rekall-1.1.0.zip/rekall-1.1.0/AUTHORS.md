# Rekall Authors and contributors.

A possibly more current list can be found at
<https://github.com/google/rekall/graphs/contributors>.

## Rekall 1.0 Authors
[Michael Cohen](https://github.com/scudette)
[Johannes Stuettgen](https://github.com/driest)
[Jordi Sanchez](https://github.com/parkisan)
[Mikhail Bushkov](https://github.com/mbushkov)
[Joachim Metz](https://github.com/joachimmetz)
[Adam Sindelar](https://github.com/the80srobot)

The following sections are copied from the Volatility AUTHORS.txt file.

## Volatility 2.0 authors

Mike Auty
Andrew Case
Michael Cohen
Brendan Dolan-Gavitt
Michael Hale Ligh
Jamie Levy
AAron Walters

## Volatility 1.3 authors:

AAron Walters <awalters@volatilesystems.com>
Volatile Systems LLC

Brendan Dolan-Gavitt <bdolangavitt@wesleyan.edu>

## Volatools Basic authors:

AAron Walters
Komoku, Inc.

Nick L. Petroni, Jr.
Komoku, Inc.

from rekall.plugins.windows.registry import printkey_test

"""Entity subsystem."""

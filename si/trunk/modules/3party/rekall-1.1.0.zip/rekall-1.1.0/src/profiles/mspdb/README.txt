This is a test program for generating the mspdb profile.

The following files originated from http://undocumented.rawol.com/win_pdbx.zip

pdb_info.h
sbs_pdb.h

We contacted the original author (Sven B. Schreiber sbs@orgon.com) for
permission to include these files but he did not reply - These files are assumed
to be in the public domain unless we hear otherwise.


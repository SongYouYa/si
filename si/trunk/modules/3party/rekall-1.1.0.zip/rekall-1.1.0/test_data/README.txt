This directory contains test data for unit tests in volatility. 

1) Windows XP SP2 image.

size      536715264
name      xp-laptop-2005-06-25.img
sha256sum c4aeeb1b461378eef796944884d1d60adaa99cbae4d035923c144b08deee1e6e

// HC4.h

#ifndef __HC4_H
#define __HC4_H

#define BT_NAMESPACE NHC4

#define HASH_ARRAY_2
#define HASH_ARRAY_3

#include "HCMain.h"

#undef HASH_ARRAY_2
#undef HASH_ARRAY_3

#undef BT_NAMESPACE

#endif


// BranchSPARC.h

#ifndef __BRANCH_SPARC_H
#define __BRANCH_SPARC_H

#include "BranchTypes.h"

UInt32 SPARC_B_Convert(Byte *data, UInt32 size, UInt32 nowPos, int encoding);

#endif

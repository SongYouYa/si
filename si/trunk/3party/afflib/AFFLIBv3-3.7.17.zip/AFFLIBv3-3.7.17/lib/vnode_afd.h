/*
 * Distributed under the Berkeley 4-part license
 */

extern struct af_vnode vnode_afd;	/* vnode_afd.cpp */

#define AFD_DEFAULT_MAXSIZE 1024*1024*608


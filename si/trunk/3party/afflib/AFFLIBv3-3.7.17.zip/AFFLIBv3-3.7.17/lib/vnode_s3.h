/*
 * Distributed under the Berkeley 4-part license
 */


extern struct af_vnode vnode_s3;	/* vnode_s3.cpp */
